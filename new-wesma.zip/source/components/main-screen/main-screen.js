import sliderNumber from "./slider-number";
import animCanvas from "./anim-canvas";
